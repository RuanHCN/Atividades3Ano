import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Abaixo vemos o Cr7 de facão e o Messi de pistola
      </Text>
      <Image style={styles.logo} source={require('../assets/cr7.png')} />
      <Image style={styles.logo} source={require('../assets/messi.png')} />
      <text>Votação</text>
      <button id="meuBotao">Cr7</button>
      <button id="meuBotao">Messi</button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#C0C0C0',
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
  }
});
